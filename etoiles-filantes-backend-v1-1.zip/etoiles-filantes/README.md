

## Phase 3 — Boutique client et commande

L'interface client est disponible dans `apps/web/app/page.tsx` : catalogue, panier, création/connexion de compte client et formulaire de commande. Les demandes sont envoyées à l'API. Les modes de règlement sont `CASH_ON_DELIVERY` et `MOBILE_MONEY_DIRECT` ; l'application ne collecte aucune donnée de carte ou code Mobile Money et n'encaisse pas les transferts.

### Préparer les sandwichs de démonstration

Après configuration de PostgreSQL et application des migrations Prisma, exécuter :

```bash
npm --workspace apps/api run db:seed
```

### Démarrage local

Dans un terminal, démarrer l'API : `npm run dev:api`. Dans un autre, démarrer le site : `npm run dev:web`. Par défaut, le site appelle `http://localhost:4000`. Pour un autre environnement, définir `NEXT_PUBLIC_API_URL` côté web et `CLIENT_ORIGIN` côté API.

**Important :** ce livrable est un incrément de développement. Il nécessite une base PostgreSQL configurée, les dépendances installées, les migrations appliquées et des tests en environnement réel avant toute mise en production.

## Phase 4 — catalogue sandwichs + laits et photos administrateur

- Le catalogue utilise désormais `Product` avec les catégories `SANDWICH` et `MILK`.
- L’administrateur peut créer/modifier les produits via l’API protégée.
- L’administrateur connecté dans l’interface web voit un formulaire d’ajout produit.
- Le champ photo accepte JPEG, PNG et WebP (5 Mo maximum). Sur les téléphones compatibles, `capture="environment"` propose la caméra arrière ; la galerie reste également disponible.
- Les photos sont servies depuis `/uploads`. Pour une mise en production, configurer `UPLOAD_DIR` sur un volume persistant ou remplacer ce stockage local par un stockage objet durable (S3 compatible, Cloudinary, etc.).
- Le stock est décrémenté dans une transaction au moment de la commande afin d’éviter les commandes dépassant le stock disponible.

### Variables API complémentaires

- `UPLOAD_DIR=./uploads`
- `PUBLIC_API_URL=http://localhost:4000` (à remplacer par l’URL publique HTTPS de l’API en production)

### Migration de base de données

Le modèle `Sandwich` est remplacé par `Product`. **Base de la phase 3 déjà créée :** faire d’abord une sauvegarde PostgreSQL, puis exécuter une seule fois `apps/api/prisma/manual-migrations/20261029_product_catalog.sql` avec `psql` afin de conserver les anciens sandwichs et les commandes associées. Cette migration donne un stock initial de zéro aux anciens produits : l’administrateur doit renseigner les quantités réelles avant la reprise des commandes. Ne pas utiliser `prisma db push` sur cette ancienne base avant cette migration.

**Nouvelle base vide :** depuis `apps/api`, lancer `npx prisma db push` puis `npx prisma generate`. En production, préférer des migrations Prisma versionnées et une sauvegarde préalable.


## Installation locale (résumé)

1. Installer Node.js 20+ et PostgreSQL.
2. Depuis la racine, exécuter `npm install`.
3. Copier `apps/api/.env.example` vers `apps/api/.env`, renseigner `DATABASE_URL`, un `JWT_SECRET` aléatoire d’au moins 32 caractères et les URL publiques.
4. Pour une nouvelle base vide, depuis `apps/api`, exécuter `npx prisma db push` puis `npx prisma generate`.
5. Créer le premier administrateur avec `npm --workspace apps/api run admin:create` après avoir renseigné les variables `BOOTSTRAP_ADMIN_*` dans le fichier `.env`. Supprimer ensuite ces variables de bootstrap.
6. Lancer l’API et le web avec `npm run dev:api` et `npm run dev:web` dans deux terminaux.

Le formulaire de photo est obligatoire dans l’interface d’ajout : il utilise l’appareil photo arrière lorsque le navigateur mobile prend en charge l’attribut `capture`, sinon l’utilisateur peut choisir une image dans sa galerie. L’API contrôle la taille, le type MIME et la signature du fichier.


## Phase 5 — livraison, comptes livreurs et GPS temps réel

### Espaces web

- `/` : boutique client, panier sandwichs + laits, création/connexion client et commande.
- `/administration/` : connexion administrateur, création de comptes livreurs, affectation des commandes, mise à jour de préparation, confirmation manuelle d'un paiement reçu hors application et suivi des dernières positions GPS en direct.
- `/livreur/` : connexion livreur, missions affectées, récupération de commande, démarrage/arrêt du partage GPS et confirmation de livraison.
- `/suivi/` : suivi d'une commande par son propriétaire, avec carte OpenStreetMap et mises à jour Socket.IO.
- `/mes-commandes/` : historique des commandes du client connecté et accès au suivi de chacune.

### Règles GPS

Le serveur accepte une position seulement si le compte est un livreur actif, si la commande lui est affectée et si son statut est `PICKED_UP`. Les clients, livreurs affectés et administrateurs autorisés peuvent rejoindre le canal privé d'une commande. Le serveur contrôle l'accès avant de rejoindre le canal. Une position est limitée à un envoi toutes les 2,5 secondes par couple livreur/commande.

En navigateur, le GPS nécessite HTTPS (sauf localhost), une permission explicite et le maintien de la page active. Dans l'application Capacitor, le plugin natif Geolocation est utilisé, mais le suivi en arrière-plan lorsque l'application est suspendue n'est pas inclus dans ce MVP et nécessitera un plugin natif de géolocalisation en arrière-plan, une déclaration de permissions spécifique et des tests de conformité aux règles des stores.

### Paiements

Aucun paiement n'est exécuté dans l'application. Le client choisit espèces à la livraison ou transfert Mobile Money direct au vendeur. L'administrateur peut marquer manuellement la commande comme payée après vérification réelle de la réception. Ne jamais demander ni stocker PIN, OTP ou code secret Mobile Money.

## Application installable et préparation Android/iOS

Le frontend est configuré pour une exportation statique Next.js (`apps/web/out`) et une enveloppe Capacitor :

```bash
npm install
npm run build:web
npx cap add android       # une seule fois
npx cap add ios           # une seule fois, depuis macOS avec Xcode
npx cap sync
npx cap open android      # Android Studio + SDK requis
npx cap open ios          # macOS + Xcode requis
```

Avant le build de production, définir `NEXT_PUBLIC_API_URL` vers l'URL HTTPS publique de l'API. L'API doit autoriser les origines web et natives via `CLIENT_ORIGIN`, par exemple `https://www.exemple.ci,capacitor://localhost,https://localhost,http://localhost`. Les permissions de localisation doivent être vérifiées dans les projets Android et iOS générés. Le suivi GPS au premier plan est implémenté ; le suivi arrière-plan n'est pas encore certifié. Les exemples de permissions Android et iOS sont dans `native-config/` et doivent être vérifiés après génération des projets natifs.

### Déploiement Docker de préproduction

1. Copier `.env.production.example` vers `.env` et remplacer tous les secrets et domaines d'exemple.
2. Définir `NEXT_PUBLIC_API_URL` comme URL publique HTTPS de l'API avant la construction de l'image web.
3. Construire les images : `docker compose build`.
4. Démarrer la base : `docker compose up -d db`.
5. Pour une base entièrement neuve uniquement, exécuter une fois `docker compose run --rm api npx prisma db push`. Pour une base existante, sauvegarder et appliquer la migration de catalogue appropriée ; ne pas exécuter `db push` à l'aveugle.
6. Lancer `docker compose up -d`.
7. Créer l'administrateur initial : `docker compose run --rm api node scripts/create-admin.cjs`, puis retirer les variables `BOOTSTRAP_ADMIN_*` du fichier `.env` et redémarrer l'API.
8. Configurer TLS (reverse proxy ou plateforme d'hébergement), sauvegardes PostgreSQL et stockage persistant des photos.

Ce compose est un point de départ de préproduction : il ne configure pas à lui seul un nom de domaine, un certificat TLS, un fournisseur d'hébergement, un stockage d'images externe, une supervision, ni une stratégie de sauvegarde distante.

### Contrôles restant obligatoires avant publication

- Installer les dépendances et lancer les builds TypeScript/Next dans un environnement avec accès au registre npm.
- Appliquer une migration Prisma versionnée sur une base de test, puis tester les commandes concurrentes et les transitions de statut.
- Tester l'authentification, les rôles, l'isolement des commandes, les uploads et les événements Socket.IO.
- Tester la géolocalisation réelle sur plusieurs Android et iPhone, permissions refusées, perte réseau, écran verrouillé et reprise.
- Configurer politique de confidentialité, support, conditions de vente/livraison, mentions légales et déclarations de collecte de localisation.
- Générer des builds signés avec les certificats et clés du propriétaire, effectuer les tests internes, puis soumettre les fiches aux stores.

La compilation et les tests de bout en bout ne sont pas attestés dans cet environnement : le registre npm n'a pas répondu et aucune base PostgreSQL ou aucun appareil physique n'est connecté ici. Le code fourni est un incrément de développement, pas une publication prête à cliquer.
