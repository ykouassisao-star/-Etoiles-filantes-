# ÉTOILES 🌟 FILANTES — Backend initial

API REST de départ pour une application de commande/livraison de sandwichs et de lait.

## Prérequis
- Node.js 20+
- PostgreSQL 14+

## Installation
1. `npm install`
2. Copier `.env.example` vers `.env` et renseigner `DATABASE_URL` ainsi qu'un `JWT_SECRET` aléatoire d'au moins 32 caractères.
3. `npx prisma generate`
4. `npx prisma migrate dev --name init`
5. `npm run dev`

L'API écoute par défaut sur `http://localhost:4000`. Test de santé : `GET /health`.

## Routes principales
- `POST /api/auth/register` : création d'un compte client.
- `POST /api/auth/login` et `GET /api/auth/me`.
- `GET /api/products`, `POST/PATCH/DELETE /api/products` (admin pour écriture).
- `POST /api/orders`, `GET /api/orders/mine`, `GET /api/orders`.
- `PATCH /api/orders/:id/status`, `PATCH /api/orders/:id/assign-driver`, `PATCH /api/orders/:id/payment`.
- `POST /api/gps/:orderId/location`, `GET /api/gps/:orderId/location`.
- `POST /api/admin/drivers`, `PATCH /api/admin/users/:id/active`, `GET /api/admin/dashboard`.

## Créer le premier administrateur
Par sécurité, l'inscription publique ne permet de créer que des clients. Après la première migration, crée le premier admin via une procédure contrôlée côté base de données ou un script d'amorçage exécuté une seule fois par l'opérateur. Ne rends jamais publique une route qui permet de choisir son propre rôle.

## Limites de cette version
- Le socle est un point de départ et doit être audité/testé avant toute mise en production.
- L'upload photo depuis le téléphone n'est pas encore branché : `imageUrl` est prévu, il faudra ajouter un stockage d'images sécurisé.
- Le GPS est enregistré par requêtes HTTP ; le temps réel Socket.IO et le suivi fiable en arrière-plan nécessitent une phase dédiée.
- Pas de paiement intégré : Mobile Money est effectué directement au vendeur, puis l'administrateur confirme le statut hors application.
- Ajouter avant production : limitation de débit, vérification SMS du téléphone, journal d'audit, politique CORS stricte, sauvegardes DB, HTTPS, tests automatisés et procédure de réinitialisation du mot de passe.

## Création initiale du compte administrateur
Après la migration de la base, ajoute temporairement ces variables dans `.env` :
- `ADMIN_FULL_NAME` : nom de l'administrateur
- `ADMIN_PHONE` : numéro de téléphone unique
- `ADMIN_PASSWORD` : mot de passe fort de 14 à 72 caractères

Puis exécute `npm run admin:create`. Le script refuse de créer un deuxième administrateur et ne renvoie jamais le mot de passe. Supprime ensuite les trois variables `ADMIN_*` du fichier `.env`.

Ne partage jamais le fichier `.env` et ne publie pas le mot de passe administrateur dans un dépôt Git.
