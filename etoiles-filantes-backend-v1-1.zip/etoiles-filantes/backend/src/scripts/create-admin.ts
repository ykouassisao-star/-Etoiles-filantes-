import 'dotenv/config';
import bcrypt from 'bcryptjs';
import { prisma } from '../lib/prisma.js';

async function main() {
  const fullName = process.env.ADMIN_FULL_NAME?.trim();
  const phone = process.env.ADMIN_PHONE?.trim();
  const password = process.env.ADMIN_PASSWORD;

  if (!fullName || fullName.length < 2 || !phone || phone.length < 8 || !password || password.length < 14 || password.length > 72) {
    throw new Error('Définir ADMIN_FULL_NAME, ADMIN_PHONE et ADMIN_PASSWORD (14 à 72 caractères) dans .env.');
  }

  const existingAdmin = await prisma.user.findFirst({ where: { role: 'ADMIN' }, select: { id: true } });
  if (existingAdmin) throw new Error('Un administrateur existe déjà. Création initiale refusée.');

  const existingPhone = await prisma.user.findUnique({ where: { phone }, select: { id: true } });
  if (existingPhone) throw new Error('Ce numéro est déjà utilisé par un compte.');

  const passwordHash = await bcrypt.hash(password, 12);
  const admin = await prisma.user.create({
    data: { fullName, phone, passwordHash, role: 'ADMIN', isActive: true },
    select: { id: true, fullName: true, phone: true, role: true },
  });
  console.log('Administrateur initial créé :', admin);
}

main()
  .catch((error: unknown) => {
    console.error(error instanceof Error ? error.message : 'Échec de création de l’administrateur.');
    process.exitCode = 1;
  })
  .finally(async () => prisma.$disconnect());
