import { Router } from 'express';
import bcrypt from 'bcryptjs';
import jwt from 'jsonwebtoken';
import { z } from 'zod';
import { prisma } from '../lib/prisma.js';
import { authenticate } from '../middleware/auth.js';

export const authRouter = Router();
const registerSchema = z.object({ fullName: z.string().trim().min(2).max(80), phone: z.string().trim().min(8).max(20), password: z.string().min(10).max(72) });
const loginSchema = z.object({ phone: z.string().trim(), password: z.string().min(1) });

function signToken(userId: string) {
  const secret = process.env.JWT_SECRET;
  if (!secret || secret.length < 32) throw new Error('JWT_SECRET doit contenir au moins 32 caractères.');
  return jwt.sign({}, secret, { subject: userId, expiresIn: '8h' });
}

authRouter.post('/register', async (req, res) => {
  const parsed = registerSchema.safeParse(req.body);
  if (!parsed.success) return res.status(400).json({ error: 'Données invalides.', details: parsed.error.flatten() });
  const { fullName, phone, password } = parsed.data;
  const existing = await prisma.user.findUnique({ where: { phone } });
  if (existing) return res.status(409).json({ error: 'Ce numéro est déjà associé à un compte.' });
  const passwordHash = await bcrypt.hash(password, 12);
  const user = await prisma.user.create({ data: { fullName, phone, passwordHash, role: 'CLIENT' }, select: { id: true, fullName: true, phone: true, role: true } });
  return res.status(201).json({ user, token: signToken(user.id) });
});

authRouter.post('/login', async (req, res) => {
  const parsed = loginSchema.safeParse(req.body);
  if (!parsed.success) return res.status(400).json({ error: 'Données invalides.' });
  const user = await prisma.user.findUnique({ where: { phone: parsed.data.phone } });
  if (!user || !user.isActive || !(await bcrypt.compare(parsed.data.password, user.passwordHash))) return res.status(401).json({ error: 'Identifiants incorrects.' });
  return res.json({ user: { id: user.id, fullName: user.fullName, phone: user.phone, role: user.role }, token: signToken(user.id) });
});

authRouter.get('/me', authenticate, async (req, res) => {
  const user = await prisma.user.findUnique({ where: { id: req.authUser!.id }, select: { id: true, fullName: true, phone: true, role: true, isActive: true } });
  return res.json({ user });
});
