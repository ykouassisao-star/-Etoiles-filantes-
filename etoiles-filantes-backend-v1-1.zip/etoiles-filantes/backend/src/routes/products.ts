import { Router } from 'express';
import { z } from 'zod';
import { prisma } from '../lib/prisma.js';
import { authenticate, allowRoles } from '../middleware/auth.js';

export const productsRouter = Router();
const productSchema = z.object({ name: z.string().trim().min(2).max(100), category: z.enum(['SANDWICH', 'MILK']), description: z.string().max(1000).optional(), imageUrl: z.string().url().optional(), priceXof: z.number().int().positive(), stock: z.number().int().min(0), isAvailable: z.boolean().optional() });

productsRouter.get('/', async (_req, res) => {
  const products = await prisma.product.findMany({ where: { isAvailable: true, stock: { gt: 0 } }, orderBy: { createdAt: 'desc' } });
  return res.json({ products });
});
productsRouter.post('/', authenticate, allowRoles('ADMIN'), async (req, res) => {
  const parsed = productSchema.safeParse(req.body);
  if (!parsed.success) return res.status(400).json({ error: 'Données invalides.', details: parsed.error.flatten() });
  const product = await prisma.product.create({ data: parsed.data });
  return res.status(201).json({ product });
});
productsRouter.patch('/:id', authenticate, allowRoles('ADMIN'), async (req, res) => {
  const parsed = productSchema.partial().safeParse(req.body);
  if (!parsed.success) return res.status(400).json({ error: 'Données invalides.' });
  try { return res.json({ product: await prisma.product.update({ where: { id: req.params.id }, data: parsed.data }) }); }
  catch { return res.status(404).json({ error: 'Produit introuvable.' }); }
});
productsRouter.delete('/:id', authenticate, allowRoles('ADMIN'), async (req, res) => {
  try { await prisma.product.delete({ where: { id: req.params.id } }); return res.status(204).send(); }
  catch { return res.status(404).json({ error: 'Produit introuvable ou déjà commandé.' }); }
});
