import { Router } from 'express';
import bcrypt from 'bcryptjs';
import { z } from 'zod';
import { prisma } from '../lib/prisma.js';
import { authenticate, allowRoles } from '../middleware/auth.js';

export const adminRouter = Router();
adminRouter.use(authenticate, allowRoles('ADMIN'));
adminRouter.post('/drivers', async (req, res) => {
  const parsed = z.object({ fullName: z.string().trim().min(2).max(80), phone: z.string().trim().min(8).max(20), temporaryPassword: z.string().min(12).max(72) }).safeParse(req.body);
  if (!parsed.success) return res.status(400).json({ error: 'Données invalides.', details: parsed.error.flatten() });
  const passwordHash = await bcrypt.hash(parsed.data.temporaryPassword, 12);
  try {
    const driver = await prisma.user.create({ data: { fullName: parsed.data.fullName, phone: parsed.data.phone, passwordHash, role: 'DRIVER' }, select: { id: true, fullName: true, phone: true, role: true } });
    return res.status(201).json({ driver });
  } catch { return res.status(409).json({ error: 'Ce numéro est déjà utilisé.' }); }
});
adminRouter.patch('/users/:id/active', async (req, res) => {
  const parsed = z.object({ isActive: z.boolean() }).safeParse(req.body);
  if (!parsed.success) return res.status(400).json({ error: 'Valeur isActive invalide.' });
  try { return res.json({ user: await prisma.user.update({ where: { id: req.params.id }, data: { isActive: parsed.data.isActive }, select: { id: true, fullName: true, phone: true, role: true, isActive: true } }) }); }
  catch { return res.status(404).json({ error: 'Utilisateur introuvable.' }); }
});
adminRouter.get('/dashboard', async (_req, res) => {
  const [ordersCount, productsCount, usersCount, deliveredCount] = await Promise.all([
    prisma.order.count(), prisma.product.count(), prisma.user.count(), prisma.order.count({ where: { status: 'DELIVERED' } })
  ]);
  return res.json({ statistics: { ordersCount, productsCount, usersCount, deliveredCount } });
});
