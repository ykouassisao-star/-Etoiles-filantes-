import { Router } from 'express';
import { z } from 'zod';
import { prisma } from '../lib/prisma.js';
import { authenticate, allowRoles } from '../middleware/auth.js';

export const ordersRouter = Router();
const createOrderSchema = z.object({ items: z.array(z.object({ productId: z.string().min(1), quantity: z.number().int().min(1).max(50) })).min(1), paymentMethod: z.enum(['CASH_ON_DELIVERY', 'MOBILE_MONEY_DIRECT']), deliveryAddress: z.string().trim().min(5).max(500), deliveryLatitude: z.number().min(-90).max(90).optional(), deliveryLongitude: z.number().min(-180).max(180).optional(), deliveryNote: z.string().max(500).optional() });

ordersRouter.post('/', authenticate, allowRoles('CLIENT'), async (req, res) => {
  const parsed = createOrderSchema.safeParse(req.body);
  if (!parsed.success) return res.status(400).json({ error: 'Commande invalide.', details: parsed.error.flatten() });
  try {
    const order = await prisma.$transaction(async (tx) => {
      const ids = [...new Set(parsed.data.items.map(i => i.productId))];
      const products = await tx.product.findMany({ where: { id: { in: ids }, isAvailable: true } });
      if (products.length !== ids.length) throw new Error('UNAVAILABLE');
      const productMap = new Map(products.map(p => [p.id, p]));
      let totalXof = 0;
      const quantities = new Map<string, number>();
      for (const item of parsed.data.items) {
        quantities.set(item.productId, (quantities.get(item.productId) ?? 0) + item.quantity);
      }
      const orderItems = [...quantities.entries()].map(([productId, quantity]) => {
        const product = productMap.get(productId)!;
        if (product.stock < quantity) throw new Error('STOCK');
        totalXof += product.priceXof * quantity;
        if (!Number.isSafeInteger(totalXof)) throw new Error('TOTAL');
        return { productId: product.id, quantity, unitPrice: product.priceXof };
      });
      for (const [productId, quantity] of quantities.entries()) {
        const updated = await tx.product.updateMany({ where: { id: productId, isAvailable: true, stock: { gte: quantity } }, data: { stock: { decrement: quantity } } });
        if (updated.count !== 1) throw new Error('STOCK');
      }
      return tx.order.create({ data: { customerId: req.authUser!.id, paymentMethod: parsed.data.paymentMethod, totalXof, deliveryAddress: parsed.data.deliveryAddress, deliveryLatitude: parsed.data.deliveryLatitude, deliveryLongitude: parsed.data.deliveryLongitude, deliveryNote: parsed.data.deliveryNote, items: { create: orderItems } }, include: { items: { include: { product: true } } } });
    });
    return res.status(201).json({ order });
  } catch (error) {
    const message = error instanceof Error ? error.message : '';
    if (message === 'STOCK') return res.status(409).json({ error: 'Stock insuffisant pour un ou plusieurs produits.' });
    if (message === 'UNAVAILABLE') return res.status(409).json({ error: 'Un produit est indisponible.' });
    if (message === 'TOTAL') return res.status(400).json({ error: 'Le montant total dépasse la limite autorisée.' });
    throw error;
  }
});

ordersRouter.get('/mine', authenticate, allowRoles('CLIENT'), async (req, res) => {
  const orders = await prisma.order.findMany({ where: { customerId: req.authUser!.id }, include: { items: { include: { product: true } }, driver: { select: { id: true, fullName: true, phone: true } } }, orderBy: { createdAt: 'desc' } });
  return res.json({ orders });
});
ordersRouter.get('/', authenticate, allowRoles('ADMIN', 'DRIVER'), async (req, res) => {
  const orders = await prisma.order.findMany({ where: req.authUser!.role === 'DRIVER' ? { driverId: req.authUser!.id } : {}, include: { items: { include: { product: true } }, customer: { select: { id: true, fullName: true, phone: true } }, driver: { select: { id: true, fullName: true, phone: true } } }, orderBy: { createdAt: 'desc' } });
  return res.json({ orders });
});
ordersRouter.patch('/:id/status', authenticate, allowRoles('ADMIN', 'DRIVER'), async (req, res) => {
  const parsed = z.object({ status: z.enum(['ACCEPTED', 'PREPARING', 'READY', 'IN_DELIVERY', 'DELIVERED', 'CANCELLED']) }).safeParse(req.body);
  if (!parsed.success) return res.status(400).json({ error: 'Statut invalide.' });
  const order = await prisma.order.findUnique({ where: { id: req.params.id } });
  if (!order) return res.status(404).json({ error: 'Commande introuvable.' });
  if (req.authUser!.role === 'DRIVER') {
    if (order.driverId !== req.authUser!.id) return res.status(403).json({ error: 'Cette livraison ne vous est pas attribuée.' });
    if (!['IN_DELIVERY', 'DELIVERED'].includes(parsed.data.status)) return res.status(403).json({ error: 'Le livreur ne peut modifier que le statut de livraison.' });
    if (order.status !== 'READY' && order.status !== 'IN_DELIVERY') return res.status(409).json({ error: 'Cette commande n’est pas prête pour la livraison.' });
  }
  return res.json({ order: await prisma.order.update({ where: { id: order.id }, data: { status: parsed.data.status } }) });
});
ordersRouter.patch('/:id/assign-driver', authenticate, allowRoles('ADMIN'), async (req, res) => {
  const parsed = z.object({ driverId: z.string().min(1) }).safeParse(req.body);
  if (!parsed.success) return res.status(400).json({ error: 'Livreur invalide.' });
  const driver = await prisma.user.findFirst({ where: { id: parsed.data.driverId, role: 'DRIVER', isActive: true } });
  if (!driver) return res.status(404).json({ error: 'Livreur actif introuvable.' });
  try { return res.json({ order: await prisma.order.update({ where: { id: req.params.id }, data: { driverId: driver.id } }) }); }
  catch { return res.status(404).json({ error: 'Commande introuvable.' }); }
});
ordersRouter.patch('/:id/payment', authenticate, allowRoles('ADMIN'), async (req, res) => {
  const parsed = z.object({ paymentStatus: z.enum(['UNCONFIRMED', 'CONFIRMED']) }).safeParse(req.body);
  if (!parsed.success) return res.status(400).json({ error: 'Statut de paiement invalide.' });
  try { return res.json({ order: await prisma.order.update({ where: { id: req.params.id }, data: { paymentStatus: parsed.data.paymentStatus } }) }); }
  catch { return res.status(404).json({ error: 'Commande introuvable.' }); }
});
