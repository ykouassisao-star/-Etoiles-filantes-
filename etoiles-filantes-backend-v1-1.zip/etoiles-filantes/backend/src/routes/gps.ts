import { Router } from 'express';
import { z } from 'zod';
import { prisma } from '../lib/prisma.js';
import { authenticate, allowRoles } from '../middleware/auth.js';

export const gpsRouter = Router();
const locationSchema = z.object({ latitude: z.number().min(-90).max(90), longitude: z.number().min(-180).max(180) });

gpsRouter.post('/:orderId/location', authenticate, allowRoles('DRIVER'), async (req, res) => {
  const parsed = locationSchema.safeParse(req.body);
  if (!parsed.success) return res.status(400).json({ error: 'Coordonnées GPS invalides.' });
  const order = await prisma.order.findFirst({ where: { id: req.params.orderId, driverId: req.authUser!.id, status: 'IN_DELIVERY' } });
  if (!order) return res.status(404).json({ error: 'Livraison active introuvable.' });
  const location = await prisma.driverLocation.create({ data: { orderId: order.id, ...parsed.data } });
  return res.status(201).json({ location });
});

gpsRouter.get('/:orderId/location', authenticate, async (req, res) => {
  const order = await prisma.order.findUnique({ where: { id: req.params.orderId }, select: { id: true, customerId: true, driverId: true } });
  if (!order) return res.status(404).json({ error: 'Commande introuvable.' });
  const isAdmin = req.authUser!.role === 'ADMIN';
  const isCustomer = req.authUser!.role === 'CLIENT' && order.customerId === req.authUser!.id;
  const isAssignedDriver = req.authUser!.role === 'DRIVER' && order.driverId === req.authUser!.id;
  if (!isAdmin && !isCustomer && !isAssignedDriver) return res.status(403).json({ error: 'Accès interdit.' });
  const location = await prisma.driverLocation.findFirst({ where: { orderId: order.id }, orderBy: { createdAt: 'desc' } });
  return res.json({ location });
});
