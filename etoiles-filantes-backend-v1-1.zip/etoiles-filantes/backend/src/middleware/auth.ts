import type { Request, Response, NextFunction } from 'express';
import jwt from 'jsonwebtoken';
import { prisma } from '../lib/prisma.js';
import type { Role } from '@prisma/client';

export type AuthUser = { id: string; role: Role };
declare global {
  namespace Express {
    interface Request { authUser?: AuthUser }
  }
}

export async function authenticate(req: Request, res: Response, next: NextFunction) {
  const header = req.headers.authorization;
  if (!header?.startsWith('Bearer ')) return res.status(401).json({ error: 'Authentification requise.' });
  const secret = process.env.JWT_SECRET;
  if (!secret) return res.status(500).json({ error: 'Configuration serveur incomplète.' });
  try {
    const payload = jwt.verify(header.slice(7), secret) as jwt.JwtPayload;
    if (typeof payload.sub !== 'string') return res.status(401).json({ error: 'Jeton invalide.' });
    const user = await prisma.user.findUnique({ where: { id: payload.sub }, select: { id: true, role: true, isActive: true } });
    if (!user || !user.isActive) return res.status(401).json({ error: 'Compte introuvable ou désactivé.' });
    req.authUser = { id: user.id, role: user.role };
    next();
  } catch {
    return res.status(401).json({ error: 'Jeton invalide ou expiré.' });
  }
}

export function allowRoles(...roles: Role[]) {
  return (req: Request, res: Response, next: NextFunction) => {
    if (!req.authUser || !roles.includes(req.authUser.role)) return res.status(403).json({ error: 'Accès interdit.' });
    next();
  };
}
