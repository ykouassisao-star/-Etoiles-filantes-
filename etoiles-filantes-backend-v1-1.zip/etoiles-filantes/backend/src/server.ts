import 'dotenv/config';
import express from 'express';
import cors from 'cors';
import helmet from 'helmet';
import { authRouter } from './routes/auth.js';
import { productsRouter } from './routes/products.js';
import { ordersRouter } from './routes/orders.js';
import { gpsRouter } from './routes/gps.js';
import { adminRouter } from './routes/admin.js';

if (!process.env.DATABASE_URL) throw new Error('DATABASE_URL manquant dans .env');
if (!process.env.JWT_SECRET || process.env.JWT_SECRET.length < 32) throw new Error('JWT_SECRET doit contenir au moins 32 caractères.');

const app = express();
app.use(helmet());
app.use(cors({ origin: process.env.CLIENT_ORIGIN?.split(',') ?? 'http://localhost:3000' }));
app.use(express.json({ limit: '1mb' }));
app.get('/health', (_req, res) => res.json({ status: 'ok', application: 'ÉTOILES FILANTES API' }));
app.use('/api/auth', authRouter);
app.use('/api/products', productsRouter);
app.use('/api/orders', ordersRouter);
app.use('/api/gps', gpsRouter);
app.use('/api/admin', adminRouter);
app.use((err: unknown, _req: express.Request, res: express.Response, _next: express.NextFunction) => {
  console.error(err);
  return res.status(500).json({ error: 'Une erreur interne est survenue.' });
});

const port = Number(process.env.PORT ?? 4000);
app.listen(port, () => console.log(`ÉTOILES FILANTES API disponible sur le port ${port}`));
