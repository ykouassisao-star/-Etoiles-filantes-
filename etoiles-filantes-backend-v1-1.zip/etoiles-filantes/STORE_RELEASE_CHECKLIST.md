# Publication checklist — ÉTOILES 🌟 FILANTES

## Avant les builds natifs
- [ ] Domaine web et API en HTTPS, DNS et certificats TLS actifs.
- [ ] Base PostgreSQL de production, sauvegardes automatiques et restauration testée.
- [ ] Stockage persistant et sauvegardé des photos produits.
- [ ] Secrets de production générés, compte administrateur bootstrap créé puis secrets bootstrap retirés.
- [ ] Politique de confidentialité, conditions de vente/livraison, mentions légales et contact support publiés.
- [ ] Déclaration claire de l'utilisation de la localisation du livreur et de sa finalité.
- [ ] Tests de sécurité des rôles, accès aux commandes, uploads, limitation de débit et Socket.IO.
- [ ] Tests réels de commande, stock, annulation, affectation, livraison et confirmation manuelle des paiements externes.

## Android / Google Play
- [ ] Ouvrir le projet Capacitor Android dans Android Studio sur une machine configurée avec Android SDK.
- [ ] Vérifier `applicationId` : `ci.etoilesfilantes.app` (doit rester stable après publication).
- [ ] Définir les permissions de localisation nécessaires, avec explication visible à l'utilisateur.
- [ ] Configurer la signature de release et sauvegarder la clé de signature en lieu sûr.
- [ ] Construire un Android App Bundle (`.aab`) de release.
- [ ] Tester l'AAB sur appareils réels et piste de test interne/fermée.
- [ ] Préparer icône, captures d'écran, description, catégorie, coordonnées de support et formulaire de sécurité des données.
- [ ] Soumettre dans Google Play Console et traiter les retours de revue.

## iOS / Apple App Store
- [ ] Ouvrir le projet Capacitor iOS sur macOS avec Xcode.
- [ ] Vérifier le Bundle Identifier : `ci.etoilesfilantes.app` (ou choisir un identifiant disponible avant la première soumission).
- [ ] Ajouter les descriptions d'usage de la localisation dans `Info.plist` et tester les autorisations.
- [ ] Configurer certificats, profils de provisioning et signature de distribution.
- [ ] Archiver l'application et envoyer le build à App Store Connect.
- [ ] Tester avec TestFlight sur iPhone réel.
- [ ] Préparer icône 1024x1024 (`apps/web/public/icons/app-store-1024.png` fournie comme base), captures d'écran, description, URL de politique de confidentialité et informations de contact.
- [ ] Soumettre pour revue Apple et traiter les retours.

## Limites connues de la version de développement
- Le GPS fonctionne au premier plan avec l'application/page active. Le suivi en arrière-plan lorsque le téléphone verrouille ou suspend l'application demande un module natif dédié, une justification produit, des permissions additionnelles et une validation sur appareils réels.
- Les paiements ne sont pas encaissés dans l'application. L'administrateur confirme manuellement le paiement après vérification auprès du vendeur.
- Les comptes de développeur, certificats, clés de signature, informations légales, captures d'écran et soumissions doivent être fournis/effectués par le propriétaire du produit.
